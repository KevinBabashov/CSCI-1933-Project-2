Group members’ names and x500s
Kevin Babashov babas007
Takuya Paipoovong paipo001
• Contributions of each partner (if working with a partner)
• How to compile and run your program
In order to play the game created with the files in the chess codepack simply run the game main file while in Intellij.
• Any assumptions
Not to the creators knowledge
• Additional features that you implemented (if applicable)
If you try to promote pawn to an option that is not listed or misspell it will call the function again with the same parameters. I am entirely confident in this logic, but it may be seen as quite peculiar.
• Any known bugs or defects in the program
Not to the creators knowledge.
• Any outside sources (aside from course resources) consulted for ideas used in the project, in
the format:
– idea1: JavaTPoint
– idea2: GeeksForGeeks
– idea3: Stack Overflow

“I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”
Kevin Babashov
Takuya Paipoovong